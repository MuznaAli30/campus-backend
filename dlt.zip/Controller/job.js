import UserModal from "../Models/job.js";

export const addjob = async (req, res) => { 
  const { jobDescription, jobTitle, userid } = req.body;
  try {
    const result = await UserModal.create({ jobDescription, jobTitle, userid });


    res.status(201).json({ success: true, });
  } catch (error) {
    if (!jobDescription || !jobTitle || !userid) {
    res.status(500).json({ success: false, message: "Something went wrong" });
    console.log(error);
  }}
};

export const getAllUsers = async ( req,res) => {
  try {
    const users = await UserModal.find();
    res.status(200).json(users);
  } catch (error) {
    res.status(500).json({ message: 'Internal server error' });
  }
};


// delete api 
export const deletepost = async (req, res) => {
  const abc='653543aa27d694328f380502'
  // const abc = req.params.id;
  let result = await UserModal.deleteOne(
    { _id: req.body},
    { $set: req.body }
  );
  res.send(abc);
};

// update api
export const updatepost = async (req, res) => {
  const abc='652ce1e177ddfad9009e4b7e'
  // const abc = req.params.id;
  let result = await UserModal.updateOne(
    { _id: req.body },
    { $set: req.body }
  );

  res.send(abc);
};