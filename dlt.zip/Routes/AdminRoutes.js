// import express from "express";
// const router = express.Router();

// import {AdminController} from "../Controller/AdminPassword.js";

// router.post("/Password", AdminController);


// export default router;