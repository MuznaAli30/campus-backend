import mongoose from "mongoose";

const userSchema = new mongoose.Schema({
    jobTitle:{
        type : String,
        require: true,
    },
    jobDescription:{
        type : String,
        require: true,
    },
})

const Users = mongoose.model("job",userSchema);
export default Users